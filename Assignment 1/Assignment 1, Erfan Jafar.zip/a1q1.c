#include <stdio.h>

	int main() {
	
	
		// first loop
		printf("a ------------------------------------------->\n");
		
		for(int i = 0; i < 10; i = i + 2){
			printf("%d\n", i);
			}
		
		// second loop
		printf("\n\nb ------------------------------------------->\n");
		
		for(int i = 100; i>= 0; i = i - 7){
			printf("%d\n", i);
			}
			
		// third loop	
		printf("\n\nc ------------------------------------------->\n");
		
		for(int i = 1; i <= 10; i = i + 1){
			printf("%d\n", i);
			}
			
		// fourth loop	
		printf("\n\nd ------------------------------------------->\n");
		
		for(int i = 2; i <100; i = i*2){
			printf("%d\n", i);
			}
		
					
	}
